﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using Microsoft.AspNetCore.Identity;
using api.Data;
using api.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> manager;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly ApiDbContext _context;
        private readonly RoleManager<IdentityRole> roleManager;
        private IConfiguration _config;
        public AuthController(UserManager<ApplicationUser> manager, SignInManager<ApplicationUser> signInManager, ApiDbContext context, RoleManager<IdentityRole> roleManager, IConfiguration config)
        {
            this.manager = manager;
            this.signInManager = signInManager;
            _context = context;
            this.roleManager = roleManager;
            _config = config;
        }

        [HttpPost("login")]
        public async Task<ActionResult<ApplicationUser>> Login(UserLogin login)
        {
            var results = await signInManager.PasswordSignInAsync(login.Email, login.Password, false, false);

            if (results.Succeeded)
            {
                var user = await manager.FindByEmailAsync(login.Email);
                if (user != null)
                {
                    return Ok(user);
                }
                else
                {
                    return NotFound("User not found");
                }
            }
            else
            {
                return NotFound("Incorrect usrname or password");
            }
        }
        [HttpPost("signup/customer")]
        public async Task<ActionResult> SignUp(UserSignUp signUp)
        {
            ApplicationUser users = new()
            {
                Email = signUp.Email,
                PhoneNumber = signUp.PhoneNumber,
                UserName = signUp.Email
            };

            var results = await manager.CreateAsync(users, signUp.Password);

            if (results.Succeeded)
            {
                var user = await manager.FindByEmailAsync(signUp.Email);
                await manager.AddToRoleAsync(user, signUp.Role);
                return Ok(users.Id);
            }
            else
            {
                string error = "";

                foreach (var res in results.Errors)
                {
                    error = $"{error} {res.Description}\n";
                }

                return BadRequest(error);
            }
        }
        [HttpPost("resetPassword")]
        public async Task<ActionResult> ResetPassword(UserLogin passwordReset)
        {
            var results = await manager.FindByEmailAsync(passwordReset.Email);

            if (results != null)
            {
                string token = await manager.GeneratePasswordResetTokenAsync(results);

                if (token != null)
                {
                    var token_results = await manager.ResetPasswordAsync(results, token, passwordReset.Password);

                    if (token_results.Succeeded)
                    {
                        return Ok("Password reset was succesful");
                    }
                    else
                    {
                        string error = "";

                        foreach (var err in token_results.Errors)
                        {
                            error = $"{error}{err.Description}\n";
                        }

                        return BadRequest();
                    }
                }
                else
                {
                    return NotFound("User not found");
                }
            }
            else
            {
                return NotFound();
            }
        }
        private string GenerateToken(ApplicationUser user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id),
                new Claim(ClaimTypes.Email, user.Email),
               // new Claim(ClaimTypes.GivenName, user.Name),
               // new Claim(ClaimTypes.Surname, user.Surname),
                //new Claim(ClaimTypes.Role, user.),
                new Claim(ClaimTypes.MobilePhone, user.PhoneNumber),
            };

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
              _config["Jwt:Audience"],
              claims,
              expires: DateTime.Now.AddDays(1),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

    }

    public class UserLogin
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class UpdateUser
    {
        public string Id { get; set; }
        public string Url { get; set; }
    }
    [NotMapped]
    public class UserSignUp
    {
        [Key]
        public string Id { get; set; }
        [DisplayName("EMAIL")]
        public string Email { get; set; }
        [DisplayName("PASSWORD")]
        public string Password { get; set; }
        [DisplayName("FIRST NAME")]
        public string Firstname { get; set; }
        [DisplayName("LAST NAME")]
        public string Lastname { get; set; }
        [DisplayName("PHONE NUMBER")]
        public string PhoneNumber { get; set; }
        public string Role { get; set; }
        public string Url { get; set; }
    }
}

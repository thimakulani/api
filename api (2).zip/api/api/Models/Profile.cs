﻿using System.ComponentModel.DataAnnotations.Schema;

namespace api.Models
{
    public class Profile
    {
        public int ProfileId { get; set; }
        [ForeignKey(nameof(Models.ApplicationUser))]
        public string Uid { get; set; }
        public virtual ApplicationUser ApplicationUser { get; set; }
        public string Name { get; set; }
        public string ImgUrl { get; set; }
        public virtual ICollection<ArtistsServices> ArtistsServices { get; set; } 
        public virtual ICollection<Address> Addresses { get; set; }   
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; } 
        public string Status { get; set; }
        public string AccountStatusDescription { get; set; }
    }
}
 
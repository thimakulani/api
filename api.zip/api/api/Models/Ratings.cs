﻿using System.ComponentModel.DataAnnotations.Schema;

namespace api.Models
{
    public class Ratings
    {
        public int Id { get; set; }
        public int Rate { get; set; }
        public string Review { get; set; } 
        [ForeignKey(nameof(Models.Profile))]
        public int ProfileId { get; set; }
        Profile Profile { get; set; }
        [ForeignKey(nameof(ApplicationUser))]
        public string CustomerId {  get; set; }
        public ApplicationUser Customer { get; set; }
    }
}

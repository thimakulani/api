﻿namespace api.Models
{
    public class Profile
    {
        public int ProfileId { get; set; }
        public string Name { get; set; }
        public string ImgUrl { get; set; }
        public virtual ICollection<ArtistsServices> ArtistsServices { get; set; } 
        public virtual ICollection<Address> Addresses { get; set; }  
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; } 
    }
}
 
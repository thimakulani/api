﻿using System.ComponentModel.DataAnnotations.Schema;

namespace api.Models
{
    public class ArtistsServices
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public double Discount { get; set; } 
        public int EstimatedDuration { get; set; }
        [ForeignKey(nameof(Models.Profile))]
        public int ProfileId { get; set; }
        public virtual Profile Profile { get; set; }

    }
}

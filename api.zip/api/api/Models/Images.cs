﻿using System.ComponentModel.DataAnnotations.Schema;

namespace api.Models
{
    public class Images
    {
        public int Id { get; set; }
        public string ImageUrl { get; set; }
        [ForeignKey(nameof(Models.Profile))]
        public int ProfileId { get; set; }
        Profile Profile { get; set; }
    }
}

﻿using Microsoft.AspNetCore.SignalR;

namespace api.Hubs
{
    public class ApiHub : Hub
    {
        public ApiHub()
        {

        }
    }
}

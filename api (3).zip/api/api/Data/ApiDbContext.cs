﻿using api.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace api.Data
{
    public class ApiDbContext : IdentityDbContext
    {
        public ApiDbContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Address> Address { get; set; }
        public DbSet<ArtistsServices> ArtistsServices { get; set; }
        public DbSet<Bookings> Bookings { get; set; }
        public DbSet<Images> Images { get; set; } 
        public DbSet<Ratings> Ratings { get; set; }
        public DbSet<ServiceTypes> ServiceTypes { get; set; } 
        public DbSet<Profile> Profile { get; set; }  
    }
}

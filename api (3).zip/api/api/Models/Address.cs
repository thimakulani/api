﻿using System.ComponentModel.DataAnnotations.Schema;

namespace api.Models
{
    public class Address
    {
        public int Id { get; set; } 
        public string Description { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public int ProfileId { get; set; }
    }
}

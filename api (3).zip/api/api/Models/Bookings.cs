﻿using System.ComponentModel.DataAnnotations.Schema;

namespace api.Models
{
    public class Bookings
    {
        public int Id { get; set; }
        public string Description { get; set; }
        
        public DateTime DateCreated { get; set; }
        public DateTime DateUpdated { get; set; }
        public DateTime BookDate { get; set; }
        [ForeignKey(nameof(ServiceTypes))]
        public int ServiceTypeId { get; set; }
        public virtual ServiceTypes ServiceType { get; set; }
        [ForeignKey(nameof(Models.Profile))]
        public int ProfileId { get; set; }
        public virtual Profile Profile { get; set; }
        public string Status { get; set; }
        public bool IsDeleted { get; set; }

        [ForeignKey(nameof(Models.ApplicationUser))]
        public string Uid { get; set; }
        public virtual ApplicationUser ApplicationUser { get; set; }

    }
}

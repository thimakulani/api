﻿using Microsoft.AspNetCore.Identity;

namespace api.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string Name { get; set; }
        public string LastName { get; set; }
        public string ProfileImage { get; set; } 
        public DateTime CreatedDate { get; set; }
    }
    
}

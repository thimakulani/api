﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using api.Data;
using api.Models;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServiceTypesController : ControllerBase
    {
        private readonly ApiDbContext _context;

        public ServiceTypesController(ApiDbContext context)
        {
            _context = context;
        }

        // GET: api/ServiceTypes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ServiceTypes>>> GetServiceTypes()
        {
            return await _context.ServiceTypes.ToListAsync();
        }

        // GET: api/ServiceTypes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ServiceTypes>> GetServiceTypes(int id)
        {
            var serviceTypes = await _context.ServiceTypes.FindAsync(id);

            if (serviceTypes == null)
            {
                return NotFound();
            }

            return serviceTypes;
        }

        // PUT: api/ServiceTypes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutServiceTypes(int id, ServiceTypes serviceTypes)
        {
            if (id != serviceTypes.Id)
            {
                return BadRequest();
            }

            _context.Entry(serviceTypes).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ServiceTypesExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ServiceTypes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ServiceTypes>> PostServiceTypes(ServiceTypes serviceTypes)
        {
            _context.ServiceTypes.Add(serviceTypes);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetServiceTypes", new { id = serviceTypes.Id }, serviceTypes);
        }

        // DELETE: api/ServiceTypes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteServiceTypes(int id)
        {
            var serviceTypes = await _context.ServiceTypes.FindAsync(id);
            if (serviceTypes == null)
            {
                return NotFound();
            }

            _context.ServiceTypes.Remove(serviceTypes);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ServiceTypesExists(int id)
        {
            return _context.ServiceTypes.Any(e => e.Id == id);
        }
    }
}
